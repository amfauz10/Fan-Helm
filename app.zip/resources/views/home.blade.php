@extends('layouts.app')

@section('title', 'Fan Helm - Official Store Helm Premium & SNI')

@section('content')
    <style>
        .trust-banner {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin: 20px auto 50px;
        }
        .trust-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 14px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.02);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .trust-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.06);
        }
        .trust-icon {
            width: 46px;
            height: 46px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--first-color) 0%, var(--first-color-alt) 100%);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
            box-shadow: 0 6px 14px rgba(225, 6, 0, 0.25);
        }
        .trust-title {
            font-size: 0.95rem;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 2px;
        }
        .trust-desc {
            font-size: 0.8rem;
            color: #64748b;
        }

        /* CARD PRODUCTS MODERN */
        .product-card-modern {
            background: #ffffff;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            padding: 24px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
            position: relative;
        }
        .product-card-modern:hover {
            transform: translateY(-6px);
            box-shadow: 0 12px 28px rgba(0,0,0,0.08);
            border-color: #cbd5e1;
        }
        .product-img-box {
            width: 100%;
            height: 190px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
        }
        .product-img-box img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            transition: transform 0.3s ease;
        }
        .product-card-modern:hover .product-img-box img {
            transform: scale(1.05);
        }
        .product-title {
            font-size: 1.15rem;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
        }
        .product-cat {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            color: var(--first-color);
            background: rgba(225, 6, 0, 0.08);
            padding: 3px 12px;
            border-radius: 20px;
            margin-bottom: 10px;
            display: inline-block;
        }
        .product-price {
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--first-color);
            margin-bottom: 16px;
        }
        .product-actions {
            display: flex;
            align-items: center;
            gap: 8px;
            width: 100%;
        }
        .btn-detail-link {
            flex: 1;
            padding: 10px;
            background: var(--accent-dark);
            color: #fff;
            border-radius: 10px;
            font-size: 0.88rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            text-decoration: none;
            transition: background 0.2s;
        }
        .btn-detail-link:hover {
            background: var(--first-color);
        }
        .btn-quick-cart {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            background: rgba(218, 90, 71, 0.1);
            color: var(--first-color);
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            transition: all 0.2s;
        }
        .btn-quick-cart:hover {
            background: var(--first-color);
            color: #fff;
        }
        .hero-img-wrap {
            position: relative;
            display: inline-block;
        }
    </style>

    <!--========== HOME SLIDESHOW ==========-->
    <section class="home" id="home" style="padding-top: calc(var(--header-height) + 1rem);">
        <div class="slideshow-container">
            @foreach($heroProducts as $index => $hero)
                <div class="mySlides fade">
                    <div class="home__container bd-container bd-grid" style="align-items: center;">
                        <div class="home__data">
                            <span class="section-subtitle" style="text-transform: uppercase; letter-spacing: 1px; font-weight: 700;">
                                Koleksi Helm Terbaik
                            </span>
                            <h1 class="home__title" style="margin: 8px 0 12px;">{{ $hero->name }}</h1>
                            <h2 class="home__subtitle" style="font-weight: 500; font-size: 1.15rem; color: #64748b; margin-bottom: 24px;">
                                {{ $hero->subtitle }}
                            </h2>
                            <div style="display: flex; gap: 14px; align-items: center;">
                                <a href="{{ route('product.show', $hero->slug) }}" class="button" style="padding: 14px 28px; font-size: 0.95rem;">
                                    Jelajahi Sekarang &rarr;
                                </a>
                                <a href="#products" style="font-weight: 600; color: #475569; padding: 12px 18px; text-decoration: none;">
                                    Lihat Semua Helm
                                </a>
                            </div>
                        </div>
                        <div class="hero-img-wrap" style="text-align: center;">
                            <img src="{{ asset($hero->image) }}" alt="{{ $hero->name }}" class="home__img" style="position: relative; z-index: 1; filter: drop-shadow(0 15px 25px rgba(0,0,0,0.25));">
                            <span style="position: absolute; top: 10px; right: 10px; z-index: 2; background: var(--accent-yellow); color: #1a1200; font-weight: 800; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.4px; padding: 6px 12px; border-radius: 20px; box-shadow: 0 6px 14px rgba(0,0,0,0.15);">
                                SNI Certified
                            </span>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <br>
    </section>

    <!-- Slide controls -->
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

    <div style="text-align:center; margin-bottom: 30px;">
        @foreach($heroProducts as $index => $hero)
            <span class="dots" onclick="currentSlide({{ $index + 1 }})"></span>
        @endforeach
    </div>

    <!--========== TRUST VALUE PROPOSITION ==========-->
    <div class="bd-container">
        <div class="trust-banner">
            <div class="trust-card">
                <div class="trust-icon">
                    <i class='bx bx-check-shield'></i>
                </div>
                <div>
                    <div class="trust-title">SNI Resmi & Asli</div>
                    <div class="trust-desc">Standar keamanan teruji & tersertifikasi</div>
                </div>
            </div>

            <div class="trust-card">
                <div class="trust-icon">
                    <i class='bx bx-package'></i>
                </div>
                <div>
                    <div class="trust-title">Pengiriman Aman</div>
                    <div class="trust-desc">Packing kardus tebal & bubble wrap</div>
                </div>
            </div>

            <div class="trust-card">
                <div class="trust-icon">
                    <i class='bx bx-sync'></i>
                </div>
                <div>
                    <div class="trust-title">Garansi Tukar Ukuran</div>
                    <div class="trust-desc">Bebas tukar ukuran bila tidak pas</div>
                </div>
            </div>

            <div class="trust-card">
                <div class="trust-icon">
                    <i class='bx bx-support'></i>
                </div>
                <div>
                    <div class="trust-title">Bantuan Ramah 24/7</div>
                    <div class="trust-desc">Konsultasi helm langsung via WhatsApp</div>
                </div>
            </div>
        </div>
    </div>

    <!--========== PRODUCTS WEEKLY SECTION ==========-->
    <section class="products section bd-container" id="products">
        <div style="text-align: center; margin-bottom: 36px;">
            <span class="section-subtitle" style="font-weight: 700; text-transform: uppercase;">Pilihan Terbaik Minggu Ini</span>
            <h2 class="section-title" style="margin-top: 4px;">Koleksi Helm Populer</h2>
            <p style="max-width: 550px; margin: 8px auto 0; color: #64748b; font-size: 0.95rem;">
                Dibuat dengan bahan ABS thermoplastic berkualitas, interior empuk yang dapat dicuci, dan sistem ventilasi optimal.
            </p>
        </div>

        <div class="products__container bd-grid logo-slider slick_two">
            @foreach($products as $prod)
                <div class="product-card-modern">
                    <div class="product-img-box">
                        <img src="{{ asset($prod->image) }}" alt="{{ $prod->name }}">
                    </div>
                    <span class="product-cat">{{ $prod->category }}</span>
                    <h3 class="product-title">{{ $prod->name }}</h3>
                    
                    <div style="display: flex; align-items: center; gap: 4px; color: #f59e0b; font-size: 0.82rem; margin-bottom: 10px;">
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <span style="color: #64748b; margin-left: 4px;">(5.0)</span>
                    </div>

                    <div class="product-price">{{ $prod->formatted_price }}</div>

                    <div class="product-actions">
                        <a href="{{ route('product.show', $prod->slug) }}" class="btn-detail-link">
                            Detail Produk
                        </a>
                        <form action="{{ route('cart.add') }}" method="POST" style="margin: 0;">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $prod->id }}">
                            <button type="submit" class="btn-quick-cart" title="Tambah Cepat ke Keranjang">
                                <i class='bx bx-cart-add'></i>
                            </button>
                        </form>
                    </div>
                </div>
            @endforeach
        </div>
    </section>

    <!--========== ABOUT ==========-->
    <section class="about section bd-container" id="about">
        <div class="about__container bd-grid" style="align-items: center;">
            <div class="about__data">
                <span class="section-subtitle about__initial">Tentang Fan Helmet</span>
                <h2 class="section-title about__initial">Dedikasi Untuk Keselamatan & Gaya Berkendara Anda</h2>
                <p class="about__description" style="line-height: 1.7;">
                    Fan Helmet didirikan dengan misi menghadirkan helm berstandar SNI kelas dunia tanpa mengorbankan estetika dan kenyamanan. Setiap helm kami melewati uji ketahanan benturan dan proses pengecatan multi-lapis presisi tinggi agar tahan terhadap cuaca ekstrem.
                </p>
                <div style="margin-top: 24px; display: flex; gap: 20px;">
                    <div>
                        <div style="font-size: 1.6rem; font-weight: 800; color: var(--first-color);">10.000+</div>
                        <div style="font-size: 0.82rem; color: #64748b;">Riders Puas</div>
                    </div>
                    <div>
                        <div style="font-size: 1.6rem; font-weight: 800; color: var(--first-color);">100%</div>
                        <div style="font-size: 0.82rem; color: #64748b;">Lolos Uji SNI</div>
                    </div>
                </div>
            </div>

            <img src="{{ asset('assets/img/about.jpg') }}" alt="Tentang Fan Helmet" class="about__img" style="border-radius: 16px; box-shadow: 0 12px 30px rgba(0,0,0,0.1);">
        </div>
    </section>

    <!--========== SERVICES / KEUNGGULAN ==========-->
    <section class="services section bd-container" id="services">
        <div style="text-align: center; margin-bottom: 36px;">
            <span class="section-subtitle" style="font-weight: 700; text-transform: uppercase;">Keunggulan Produk Kami</span>
            <h2 class="section-title">Standar Kualitas Tanpa Kompromi</h2>
        </div>

        <div class="services__container bd-grid">
            <div class="services__content" style="background: #fff; border-radius: 16px; padding: 28px; border: 1px solid #e2e8f0; text-align: center;">
                <img src="{{ asset('assets/img/helmet-upper.jpeg') }}" alt="Pengecatan" class="services__img" style="border-radius: 12px; margin: 0 auto 16px;">
                <h3 class="services__title">Pengecatan Ultra-Glossy & Doff</h3>
                <p class="services__description">Cat polyurethane premium tahan gores dan tidak mudah pudar terkena terik matahari.</p>
            </div>

            <div class="services__content" style="background: #fff; border-radius: 16px; padding: 28px; border: 1px solid #e2e8f0; text-align: center;">
                <img src="{{ asset('assets/img/helmet-visor.jpg') }}" alt="Pemasangan" class="services__img" style="border-radius: 12px; margin: 0 auto 16px;">
                <h3 class="services__title">Visor Anti-Scratch & UV Protection</h3>
                <p class="services__description">Pandangan jernih tanpa distorsi optik, melindungi mata dari silau dan serangga.</p>
            </div>

            <div class="services__content" style="background: #fff; border-radius: 16px; padding: 28px; border: 1px solid #e2e8f0; text-align: center;">
                <img src="{{ asset('assets/img/helmet-design.jpg') }}" alt="SNI" class="services__img" style="border-radius: 12px; margin: 0 auto 16px;">
                <h3 class="services__title">Sertifikasi SNI 1811-2007</h3>
                <p class="services__description">Telah lolos uji ketahanan penetrasi dan pelepasan tali pengikat standar nasional.</p>
            </div>
        </div>
    </section>

    <!--===== SIZE CHART =======-->
    <section class="size section bd-container" id="size">
        <div class="size__container bd-grid" style="align-items: center;">
            <div class="size__data">
                <span class="section-subtitle size__initial">Panduan Ukuran Helm</span>
                <h2 class="section-title size__initial">Cari Ukuran Helm Yang Pas di Kepala Anda</h2>
                <p class="size__description" style="line-height: 1.7;">
                    Helm yang terlalu longgar akan berbahaya saat benturan, sedangkan helm yang terlalu sempit akan membuat kepala pusing. Ukur lingkar kepala Anda tepat di atas alis menggunakan meteran kain dan cocokkan dengan tabel ukuran di samping.
                </p>
            </div>
            <div style="text-align: center;">
                <img src="{{ asset('assets/img/size-chart.png') }}" alt="Size Chart" class="size__img" style="border-radius: 14px; background: #fff; padding: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 16px rgba(0,0,0,0.05);">
            </div>
        </div>
    </section> 

    <!--========== CONTACT CTA ==========-->
    <section class="contact section bd-container" id="contact" style="margin-bottom: 40px;">
        <div class="contact__container bd-grid" style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); border-radius: 20px; padding: 48px 40px; color: #fff; align-items: center;">
            <div class="contact__data">
                <span style="color: #f87171; font-weight: 700; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.5px;">Butuh Bantuan Memilih Helm?</span>
                <h2 style="color: #fff; font-size: 1.8rem; font-weight: 800; margin: 8px 0 12px;">Konsultasikan Langsung Dengan Tim Ahli Kami</h2>
                <p style="color: #94a3b8; font-size: 0.95rem; line-height: 1.6;">Kami siap membantu merekomendasikan varian helm dan ukuran yang paling pas untuk model motor dan gaya berkendara Anda.</p>
            </div>

            <div class="contact__button" style="text-align: right;">
                <a href="{{ route('contact.index') }}" class="button" style="background: var(--first-color); padding: 14px 28px; font-size: 0.95rem; box-shadow: 0 6px 20px rgba(218, 90, 71, 0.4);">
                    Hubungi Kami Sekarang &rarr;
                </a>
            </div>
        </div>
    </section>
@endsection

@push('scripts')
<script>
    $(document).ready(function(){
        if ($('.slick_two').length) {
            $('.slick_two').slick({
                dots: true,
                arrows: true,                
                infinite: true,
                autoplay: true,
                speed: 1200,
                autoplaySpeed: 3000,
                slidesToShow: 3,
                slidesToScroll: 1,
                responsive: [
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 640,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });
        }
    });
</script>
@endpush