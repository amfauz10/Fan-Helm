<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin Executive - Fan Helmet')</title>

    <!-- Fonts: Fraunces (judul, serif elegan) + Plus Jakarta Sans (isi) + IBM Plex Mono (kode & angka) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">

    <!-- Boxicons -->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        :root {
            /* Palet netral dingin dengan satu aksen emas tua - dipakai hemat,
               bukan ditaburkan ke semua elemen. Sengaja beda dari merah toko
               depan supaya operator sadar sedang di area admin. */
            --ink: #171a1f;
            --primary: #171a1f;
            --primary-hover: #2b303a;
            --gold: #a9791f;
            --gold-soft: #f3ead6;
            --sidebar-bg: #ffffff;
            --sidebar-hover: rgba(23, 26, 31, 0.05);
            --sidebar-border: var(--border-color);
            --sidebar-text: #52565f;
            --bg-main: #f2f2ef;
            --card-bg: #ffffff;
            --border-color: #e3e3de;
            --text-title: #171a1f;
            --text-body: #3c3f45;
            --text-muted: #767a82;
            --radius: 10px;
            --font-display: 'Fraunces', serif;
            --font-mono: 'IBM Plex Mono', monospace;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: var(--bg-main);
            color: var(--text-body);
            display: flex;
            min-height: 100vh;
            letter-spacing: -0.1px;
        }

        /* SIDEBAR STYLING */
        .admin-sidebar {
            width: 264px;
            background-color: var(--sidebar-bg);
            border-right: 1px solid var(--sidebar-border);
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
        }

        .sidebar-brand {
            padding: 26px 24px;
            display: flex;
            align-items: center;
            gap: 13px;
            border-bottom: 1px solid var(--sidebar-border);
            text-decoration: none;
            color: var(--ink);
        }

        .brand-icon-box {
            width: 36px;
            height: 36px;
            background: transparent;
            border: 1px solid rgba(169, 121, 31, 0.5);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
            color: var(--gold);
            flex-shrink: 0;
        }

        .brand-name {
            font-family: var(--font-display);
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--ink);
            letter-spacing: -0.2px;
            line-height: 1.2;
        }

        .sidebar-menu {
            padding: 22px 16px;
            list-style: none;
            flex: 1;
            overflow-y: auto;
        }

        .nav-item-link {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 12px;
            border-radius: 7px;
            color: var(--sidebar-text);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: background 0.15s ease, color 0.15s ease;
            margin-bottom: 1px;
            border-left: 2px solid transparent;
        }

        .nav-item-link .link-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-item-link i {
            font-size: 1.15rem;
            color: #a3a6ad;
            transition: color 0.15s;
        }

        .nav-item-link:hover {
            color: var(--ink);
            background: var(--sidebar-hover);
        }
        .nav-item-link:hover i {
            color: var(--ink);
        }

        .nav-item-link.active {
            color: var(--ink);
            background: var(--gold-soft);
            border-left: 2px solid var(--gold);
        }
        .nav-item-link.active i {
            color: var(--gold);
        }

        .nav-counter {
            font-family: var(--font-mono);
            font-size: 0.72rem;
            font-weight: 600;
            padding: 1px 7px;
            border-radius: 20px;
        }
        .counter-pending {
            background: var(--gold-soft);
            color: #8a6423;
        }
        .counter-info {
            background: #eef0f3;
            color: #565b66;
        }

        .sidebar-footer {
            padding: 18px 22px;
            border-top: 1px solid var(--sidebar-border);
        }

        /* MAIN WRAPPER */
        .admin-main {
            margin-left: 270px;
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
        }

        /* TOPBAR STYLING */
        .admin-topbar {
            height: 72px;
            background: #ffffff;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 36px;
            position: sticky;
            top: 0;
            z-index: 90;
        }

        .breadcrumb-trail {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.87rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        .breadcrumb-trail strong {
            color: var(--text-title);
            font-weight: 600;
        }

        .topbar-actions {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .btn-view-store {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 14px;
            border-radius: 7px;
            background: transparent;
            color: var(--text-body);
            font-size: 0.86rem;
            font-weight: 600;
            text-decoration: none;
            border: 1px solid var(--border-color);
            transition: border-color 0.15s, color 0.15s;
        }
        .btn-view-store:hover {
            border-color: var(--ink);
            color: var(--ink);
        }

        .admin-profile-pill {
            display: flex;
            align-items: center;
            gap: 10px;
            padding-left: 16px;
            border-left: 1px solid var(--border-color);
        }
        .admin-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--ink);
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: var(--font-display);
            font-weight: 600;
            font-size: 0.88rem;
        }

        /* CONTENT CONTAINER */
        .admin-content {
            padding: 34px 40px 64px;
            flex: 1;
            max-width: 1360px;
        }

        /* CARD & COMPONENT SYSTEM */
        .admin-card {
            background: #ffffff;
            border-radius: var(--radius);
            border: 1px solid var(--border-color);
            overflow: hidden;
            margin-bottom: 24px;
        }
        .card-header {
            padding: 19px 24px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .card-title {
            font-family: var(--font-display);
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-title);
            letter-spacing: -0.2px;
        }
        .card-body {
            padding: 24px;
        }

        /* BUTTONS */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            border-radius: 7px;
            font-size: 0.89rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            border: 1px solid transparent;
            transition: background 0.15s ease, border-color 0.15s ease;
        }
        .btn-primary {
            background: var(--ink);
            color: #fff;
        }
        .btn-primary:hover {
            background: var(--primary-hover);
        }
        .btn-secondary {
            background: transparent;
            color: var(--text-body);
            border: 1px solid var(--border-color);
        }
        .btn-secondary:hover {
            border-color: var(--ink);
            color: var(--ink);
        }
        .btn-danger {
            background: #ffffff;
            color: #b3402f;
            border: 1px solid #e8c3bb;
        }
        .btn-danger:hover {
            background: #fbf0ee;
        }
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.81rem;
            border-radius: 6px;
        }

        /* STATUS BADGES WITH DOTS */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 3px 2px;
            font-size: 0.81rem;
            font-weight: 600;
            color: var(--text-body);
        }
        .badge::before {
            content: '';
            width: 6px;
            height: 6px;
            border-radius: 50%;
            display: inline-block;
            flex-shrink: 0;
        }
        .badge-warning::before { background: #b8862f; }
        .badge-warning { color: #8a6423; }

        .badge-success::before { background: #3f8f5f; }
        .badge-success { color: #2f6b47; }

        .badge-info::before { background: #3d6fa8; }
        .badge-info { color: #305a89; }

        .badge-primary::before { background: var(--gold); }
        .badge-primary { color: #8a6423; }

        .badge-danger::before { background: #b3402f; }
        .badge-danger { color: #9a3826; }

        .badge-secondary::before { background: #90939c; }
        .badge-secondary { color: var(--text-muted); }

        /* TABLE SYSTEM */
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 0.89rem;
        }
        .admin-table th {
            padding: 13px 22px;
            background: transparent;
            color: var(--text-muted);
            font-weight: 600;
            border-bottom: 1px solid var(--border-color);
            font-size: 0.78rem;
        }
        .admin-table td {
            padding: 16px 22px;
            border-bottom: 1px solid #f0f0ec;
            vertical-align: middle;
        }
        .admin-table tr:last-child td {
            border-bottom: none;
        }
        .admin-table tr:hover td {
            background: #fafaf8;
        }

        /* FORMS */
        .form-group { margin-bottom: 20px; }
        .form-label {
            display: block;
            font-size: 0.87rem;
            font-weight: 600;
            color: var(--text-body);
            margin-bottom: 8px;
        }
        .form-control {
            width: 100%;
            padding: 11px 14px;
            border: 1px solid #d4d4cd;
            border-radius: 7px;
            font-size: 0.92rem;
            outline: none;
            transition: border-color 0.15s;
            background: #fff;
        }
        .form-control:focus {
            border-color: var(--ink);
        }

        /* ALERTS */
        .alert {
            padding: 13px 18px;
            border-radius: 8px;
            margin-bottom: 24px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
        }
        .alert-success { background: #eef6f0; color: #2f6b47; border: 1px solid #cbe4d2; }
        .alert-error { background: #fbf0ee; color: #9a3826; border: 1px solid #edcec8; }
    </style>
</head>
<body>

    @php
        $sidebarPendingCount = \App\Models\Order::where('status', 'pending')->count();
        $sidebarMessageCount = \App\Models\ContactMessage::count();
    @endphp

    <!-- SIDEBAR -->
    <aside class="admin-sidebar">
        <a href="{{ route('admin.dashboard') }}" class="sidebar-brand">
            <div class="brand-icon-box">
                <i class='bx bxs-shield'></i>
            </div>
            <div class="brand-name">Fan Helmet</div>
        </a>

        <ul class="sidebar-menu">
            <li>
                <a href="{{ route('admin.dashboard') }}" class="nav-item-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                    <div class="link-content">
                        <i class='bx bx-grid-alt'></i>
                        <span>Dashboard</span>
                    </div>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.products.index') }}" class="nav-item-link {{ request()->routeIs('admin.products.*') ? 'active' : '' }}">
                    <div class="link-content">
                        <i class='bx bx-purchase-tag-alt'></i>
                        <span>Katalog Helm</span>
                    </div>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.orders.index') }}" class="nav-item-link {{ request()->routeIs('admin.orders.*') ? 'active' : '' }}">
                    <div class="link-content">
                        <i class='bx bx-cart'></i>
                        <span>Pesanan Masuk</span>
                    </div>
                    @if($sidebarPendingCount > 0)
                        <span class="nav-counter counter-pending">{{ $sidebarPendingCount }}</span>
                    @endif
                </a>
            </li>
            <li>
                <a href="{{ route('admin.messages.index') }}" class="nav-item-link {{ request()->routeIs('admin.messages.*') ? 'active' : '' }}">
                    <div class="link-content">
                        <i class='bx bx-message-detail'></i>
                        <span>Pesan Kontak</span>
                    </div>
                    @if($sidebarMessageCount > 0)
                        <span class="nav-counter counter-info">{{ $sidebarMessageCount }}</span>
                    @endif
                </a>
            </li>

            <li style="border-top: 1px solid var(--sidebar-border); margin: 14px 0;"></li>
            <li>
                <a href="{{ route('home') }}" target="_blank" class="nav-item-link">
                    <div class="link-content">
                        <i class='bx bx-store-alt'></i>
                        <span>Halaman Depan Toko</span>
                    </div>
                    <i class='bx bx-link-external' style="font-size: 1rem;"></i>
                </a>
            </li>
        </ul>

        <div class="sidebar-footer">
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="nav-item-link" style="width:100%; background:none; border:none; cursor:pointer; color:#ef4444;">
                    <div class="link-content">
                        <i class='bx bx-log-out' style="color:#ef4444;"></i>
                        <span>Keluar (Logout)</span>
                    </div>
                </button>
            </form>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="admin-main">
        <!-- TOPBAR -->
        <header class="admin-topbar">
            <div class="breadcrumb-trail">
                <span>Admin Panel</span>
                <i class='bx bx-chevron-right'></i>
                <strong>@yield('page_title', 'Dashboard')</strong>
            </div>

            <div class="topbar-actions">
                <a href="{{ route('home') }}" target="_blank" class="btn-view-store">
                    <i class='bx bx-globe'></i> Ke Toko Depan
                </a>

                <div class="admin-profile-pill">
                    <div class="admin-avatar">
                        {{ strtoupper(substr(auth()->user()->name ?? 'A', 0, 1)) }}
                    </div>
                    <div style="font-size: 0.85rem; font-weight: 600; color: var(--text-title);">{{ auth()->user()->name ?? 'Admin' }}</div>
                </div>
            </div>
        </header>

        <!-- MAIN BODY -->
        <main class="admin-content">
            @if(session('success'))
                <div class="alert alert-success">
                    <i class='bx bx-check-circle' style="font-size: 1.3rem;"></i>
                    <span>{{ session('success') }}</span>
                </div>
            @endif

            @if(session('error'))
                <div class="alert alert-error">
                    <i class='bx bx-error-circle' style="font-size: 1.3rem;"></i>
                    <span>{{ session('error') }}</span>
                </div>
            @endif

            @yield('content')
        </main>
    </div>

    @stack('scripts')
</body>
</html>