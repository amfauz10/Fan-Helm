<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Masuk Akun - Fan Helm Official Store</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        :root {
            --primary: #e10600;
            --primary-dark: #b93826;
            --ink: #0f172a;
            --muted: #64748b;
            --line: #e2e8f0;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Plus Jakarta Sans', sans-serif; }
        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background:
                radial-gradient(circle at 15% 20%, rgba(218,90,71,.18) 0%, transparent 45%),
                radial-gradient(circle at 85% 80%, rgba(15,23,42,.10) 0%, transparent 45%),
                #f8fafc;
            padding: 24px;
        }

        .auth-shell {
            width: 100%;
            max-width: 420px;
            background: #ffffff;
            border: 1px solid var(--line);
            border-radius: 20px;
            padding: 40px 36px;
            box-shadow: 0 20px 50px -20px rgba(15, 23, 42, .18);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            justify-content: center;
            margin-bottom: 22px;
        }
        .brand .icon-box {
            width: 40px; height: 40px; border-radius: 11px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-size: 1.3rem;
        }
        .brand span { font-weight: 800; font-size: 1.2rem; color: var(--ink); letter-spacing: -.4px; }

        h1 { text-align: center; font-size: 1.55rem; font-weight: 800; color: var(--ink); letter-spacing: -.5px; }
        .sub { text-align: center; color: var(--muted); font-size: .92rem; margin: 6px 0 26px; }

        .alert-auth {
            background: #fef2f2; border: 1px solid #fecaca; border-radius: 10px;
            padding: 12px 14px; margin-bottom: 18px; display: flex; gap: 8px;
            align-items: center; color: #991b1b; font-size: .85rem; font-weight: 500;
        }
        .alert-ok {
            background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534;
        }

        .field { margin-bottom: 16px; }
        .field label { display: block; font-size: .85rem; font-weight: 600; color: #334155; margin-bottom: 6px; }
        .input-box { position: relative; display: flex; align-items: center; }
        .input-box i { position: absolute; left: 13px; color: #94a3b8; font-size: 1.15rem; }
        .input-box input {
            width: 100%; padding: 12px 42px; border: 1.5px solid var(--line); border-radius: 10px;
            font-size: .93rem; color: var(--ink); background: #f8fafc; outline: none; transition: .15s;
        }
        .input-box input:focus { background: #fff; border-color: var(--primary); box-shadow: 0 0 0 4px rgba(218,90,71,.12); }
        .toggle-pw { right: 13px; left: auto !important; cursor: pointer; }

        .row-between { display: flex; align-items: center; justify-content: space-between; margin: 4px 0 22px; font-size: .85rem; }
        .remember { display: flex; align-items: center; gap: 7px; color: #475569; cursor: pointer; }
        .remember input { accent-color: var(--primary); width: 16px; height: 16px; }

        .btn-submit {
            width: 100%; padding: 13px; border: none; border-radius: 10px; cursor: pointer;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: #fff;
            font-weight: 700; font-size: .95rem; display: flex; align-items: center; justify-content: center; gap: 8px;
            box-shadow: 0 8px 22px rgba(218,90,71,.35); transition: .2s;
        }
        .btn-submit:hover { transform: translateY(-1px); }

        .footer-line { text-align: center; margin-top: 22px; font-size: .88rem; color: var(--muted); }
        .footer-line a { color: var(--primary); font-weight: 700; text-decoration: none; }

        .back-home { display: block; text-align: center; margin-top: 14px; font-size: .82rem; color: #94a3b8; text-decoration: none; }
        .back-home:hover { color: var(--muted); }
    </style>
</head>
<body>
    <div class="auth-shell">
        <div class="brand">
            <div class="icon-box"><i class='bx bxs-shield'></i></div>
            <span>Fan Helm</span>
        </div>
        <h1>Masuk ke Akun Anda</h1>
        <p class="sub">Belanja helm premium, lacak pesanan, atau kelola toko.</p>

        @if ($errors->any())
            <div class="alert-auth">
                <i class='bx bx-error-circle' style="font-size: 1.2rem;"></i>
                <span>{{ $errors->first() }}</span>
            </div>
        @endif
        @if (session('error'))
            <div class="alert-auth"><i class='bx bx-error-circle' style="font-size: 1.2rem;"></i><span>{{ session('error') }}</span></div>
        @endif
        @if (session('success'))
            <div class="alert-auth alert-ok"><i class='bx bx-check-circle' style="font-size: 1.2rem;"></i><span>{{ session('success') }}</span></div>
        @endif

        <form action="{{ route('login.post') }}" method="POST">
            @csrf
            <div class="field">
                <label for="email">Alamat Email</label>
                <div class="input-box">
                    <i class='bx bx-envelope'></i>
                    <input type="email" name="email" id="email" value="{{ old('email') }}" placeholder="nama@email.com" required autofocus>
                </div>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <div class="input-box">
                    <i class='bx bx-lock-alt'></i>
                    <input type="password" name="password" id="password" placeholder="••••••••" required>
                    <i class='bx bx-show toggle-pw' id="togglePasswordBtn" onclick="togglePasswordVisibility()"></i>
                </div>
            </div>

            <div class="row-between">
                <label class="remember">
                    <input type="checkbox" name="remember">
                    <span>Ingat saya</span>
                </label>
            </div>

            <button type="submit" class="btn-submit">
                <span>Masuk</span>
                <i class='bx bx-right-arrow-alt' style="font-size: 1.2rem;"></i>
            </button>
        </form>

        <p class="footer-line">Belum punya akun? <a href="{{ route('register') }}">Daftar sekarang</a></p>
        <a href="{{ route('home') }}" class="back-home"><i class='bx bx-arrow-back'></i> Kembali ke Beranda Toko</a>
    </div>

    <script>
        function togglePasswordVisibility() {
            const input = document.getElementById('password');
            const btn = document.getElementById('togglePasswordBtn');
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.classList.toggle('bx-show', !show);
            btn.classList.toggle('bx-hide', show);
        }
    </script>
</body>
</html>