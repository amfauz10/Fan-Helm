@extends('layouts.app')

@section('title', $product->name . ' - Detail Helm Fan Helmet')

@section('content')
    <style>
        .product-detail-wrapper {
            padding-top: calc(var(--header-height) + 1.5rem);
            padding-bottom: 60px;
        }
        .detail-card {
            background: #ffffff;
            border-radius: 20px;
            border: 1px solid #e2e8f0;
            padding: 36px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
            display: grid;
            grid-template-columns: 1fr 1.15fr;
            gap: 40px;
            align-items: start;
        }
        @media (max-width: 860px) {
            .detail-card {
                grid-template-columns: 1fr;
                padding: 24px;
            }
        }
        .main-img-holder {
            width: 100%;
            height: 380px;
            background: #f8fafc;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            overflow: hidden;
            margin-bottom: 16px;
        }
        .main-img-holder img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            transition: transform 0.3s ease;
        }
        .thumbs-grid {
            display: flex;
            gap: 12px;
        }
        .thumb-box {
            width: 75px;
            height: 75px;
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            padding: 6px;
            transition: all 0.2s;
        }
        .thumb-box.active {
            border-color: var(--first-color);
            box-shadow: 0 0 0 3px rgba(218, 90, 71, 0.2);
        }
        .thumb-box img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        /* PILL SIZES */
        .size-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 48px;
            height: 42px;
            padding: 0 14px;
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            background: #ffffff;
            font-weight: 700;
            font-size: 0.9rem;
            color: #334155;
            cursor: pointer;
            transition: all 0.2s;
            user-select: none;
        }
        .size-pill:hover {
            border-color: #cbd5e1;
            background: #f8fafc;
        }
        .size-pill.active {
            background: #0f172a;
            color: #ffffff;
            border-color: #0f172a;
            box-shadow: 0 4px 12px rgba(15, 23, 42, 0.25);
        }

        .info-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #ecfdf5;
            color: #047857;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
        }
    </style>

    <div class="bd-container product-detail-wrapper">
        <!-- BREADCRUMB -->
        <div style="margin-bottom: 24px; font-size: 0.88rem; color: #64748b;">
            <a href="{{ route('home') }}" style="color: inherit; text-decoration: none;"><i class='bx bxs-home'></i> Beranda</a>
            <span style="margin: 0 8px;">&bull;</span>
            <a href="{{ route('home') }}#products" style="color: inherit; text-decoration: none;">Produk</a>
            <span style="margin: 0 8px;">&bull;</span>
            <span style="color: #0f172a; font-weight: 600;">{{ $product->name }}</span>
        </div>

        <div class="detail-card">
            <!-- GALLERY -->
            <div>
                <div class="main-img-holder">
                    <img id="productBigImg" src="{{ asset($product->image) }}" alt="{{ $product->name }}">
                </div>
                <div class="thumbs-grid">
                    <div class="thumb-box active" onclick="switchThumb('{{ asset($product->image) }}', this)">
                        <img src="{{ asset($product->image) }}" alt="{{ $product->name }}">
                    </div>
                    @if(!empty($product->gallery_images))
                        @foreach($product->gallery_images as $gImg)
                            <div class="thumb-box" onclick="switchThumb('{{ asset($gImg) }}', this)">
                                <img src="{{ asset($gImg) }}" alt="{{ $product->name }}">
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>

            <!-- PRODUCT INFO & BUY FORM -->
            <div>
                <div style="display: flex; gap: 8px; margin-bottom: 12px; align-items: center;">
                    <span class="badge badge-secondary" style="font-size: 0.85rem; padding: 4px 12px;">{{ $product->category }}</span>
                    <span class="info-pill"><i class='bx bx-check-circle'></i> Standar SNI Resmi</span>
                </div>

                <h1 style="font-size: 2rem; font-weight: 800; color: #0f172a; margin-bottom: 8px; letter-spacing: -0.5px;">
                    {{ $product->name }}
                </h1>

                @if($product->subtitle)
                    <p style="font-size: 1.05rem; color: #64748b; margin-bottom: 18px; font-weight: 500;">
                        {{ $product->subtitle }}
                    </p>
                @endif

                <div style="font-size: 1.85rem; font-weight: 800; color: var(--first-color); margin-bottom: 24px;">
                    {{ $product->formatted_price }}
                </div>

                <form action="{{ route('cart.add') }}" method="POST">
                    @csrf
                    <input type="hidden" name="product_id" value="{{ $product->id }}">
                    <input type="hidden" name="size" id="selectedSizeInput" value="{{ $product->sizes[0] ?? 'L' }}">

                    <!-- SIZE SELECTION -->
                    <div style="margin-bottom: 24px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <label style="font-weight: 700; font-size: 0.92rem; color: #0f172a;">
                                PILIH UKURAN: <span id="currentSizeLabel" style="color: var(--first-color);">{{ $product->sizes[0] ?? 'L' }}</span>
                            </label>
                            <a href="{{ route('home') }}#size" style="font-size: 0.82rem; color: var(--first-color); font-weight: 600;">
                                <i class='bx bx-ruler'></i> Panduan Ukuran
                            </a>
                        </div>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                            @if(!empty($product->sizes))
                                @foreach($product->sizes as $idx => $size)
                                    <div class="size-pill {{ $idx === 0 ? 'active' : '' }}" onclick="selectSize('{{ $size }}', this)">
                                        {{ $size }}
                                    </div>
                                @endforeach
                            @else
                                <div class="size-pill active" onclick="selectSize('All Size', this)">All Size</div>
                            @endif
                        </div>
                    </div>

                    <!-- QUANTITY -->
                    <div style="margin-bottom: 28px;">
                        <label style="display: block; font-weight: 700; font-size: 0.92rem; color: #0f172a; margin-bottom: 10px;">
                            JUMLAH HELM
                        </label>
                        <div style="display: inline-flex; align-items: center; border: 2px solid #e2e8f0; border-radius: 10px; overflow: hidden; background: #fff;">
                            <button type="button" onclick="adjustQty(-1)" style="width: 40px; height: 40px; background: none; border: none; font-size: 1.2rem; cursor: pointer; color: #475569;">-</button>
                            <input type="number" name="quantity" id="quantityInput" value="1" min="1" max="50" style="width: 50px; text-align: center; border: none; font-weight: 700; font-size: 1rem; outline: none;">
                            <button type="button" onclick="adjustQty(1)" style="width: 40px; height: 40px; background: none; border: none; font-size: 1.2rem; cursor: pointer; color: #475569;">+</button>
                        </div>
                    </div>

                    <!-- BUTTONS -->
                    <div style="display: flex; gap: 14px; margin-bottom: 36px;">
                        <button type="submit" class="button" style="flex: 1; justify-content: center; padding: 14px; font-size: 1rem; border-radius: 12px; border: none; cursor: pointer; box-shadow: 0 4px 16px rgba(218, 90, 71, 0.35);">
                            <i class='bx bx-cart-add' style="font-size: 1.3rem; margin-right: 6px;"></i> Tambahkan ke Keranjang
                        </button>
                    </div>
                </form>

                <!-- SPECS & MATERIAL BOX -->
                <div style="border-top: 1px solid #e2e8f0; padding-top: 24px;">
                    <div style="margin-bottom: 16px;">
                        <h4 style="font-size: 0.95rem; font-weight: 700; color: #0f172a; margin-bottom: 6px;">
                            <i class='bx bx-wrench' style="color: var(--first-color);"></i> Spesifikasi Teknis
                        </h4>
                        <p style="font-size: 0.9rem; color: #475569; line-height: 1.6;">
                            {!! nl2br(e($product->specification ?? 'Standar SNI, Visor Scratch-Resistant, Busa dapat dilepas')) !!}
                        </p>
                    </div>

                    @if($product->materials)
                        <div>
                            <h4 style="font-size: 0.95rem; font-weight: 700; color: #0f172a; margin-bottom: 6px;">
                                <i class='bx bx-shield' style="color: var(--first-color);"></i> Bahan Material
                            </h4>
                            <p style="font-size: 0.9rem; color: #475569; line-height: 1.6;">
                                {{ $product->materials }}
                            </p>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- RELATED PRODUCTS -->
        @if($relatedProducts->count() > 0)
            <div style="margin-top: 60px;">
                <h3 style="font-size: 1.4rem; font-weight: 800; color: #0f172a; margin-bottom: 24px;">
                    Helm Lain Yang Mungkin Anda Suka
                </h3>
                <div class="products__container bd-grid logo-slider slick_two">
                    @foreach($relatedProducts as $rel)
                        <div class="product-card-modern">
                            <div class="product-img-box">
                                <img src="{{ asset($rel->image) }}" alt="{{ $rel->name }}">
                            </div>
                            <span class="product-cat">{{ $rel->category }}</span>
                            <h4 class="product-title">{{ $rel->name }}</h4>
                            <div class="product-price">{{ $rel->formatted_price }}</div>
                            <div class="product-actions">
                                <a href="{{ route('product.show', $rel->slug) }}" class="btn-detail-link">
                                    Lihat Helm
                                </a>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </div>
@endsection

@push('scripts')
<script>
    function switchThumb(imgUrl, el) {
        document.querySelectorAll('.thumb-box').forEach(b => b.classList.remove('active'));
        el.classList.add('active');
        document.getElementById('productBigImg').src = imgUrl;
    }

    function selectSize(size, el) {
        document.querySelectorAll('.size-pill').forEach(b => b.classList.remove('active'));
        el.classList.add('active');
        document.getElementById('selectedSizeInput').value = size;
        document.getElementById('currentSizeLabel').innerText = size;
    }

    function adjustQty(amount) {
        var input = document.getElementById('quantityInput');
        var val = parseInt(input.value) || 1;
        val += amount;
        if (val < 1) val = 1;
        if (val > 50) val = 50;
        input.value = val;
    }
</script>
@endpush
